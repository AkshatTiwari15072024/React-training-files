import React, { useState, useEffect } from 'react';

const BookForm = ({ book, onSave, onCancel, mode}) => {
  const [bookId, setBookId] = useState('');
  const [author, setAuthor] = useState('');
  const [issuingPerson, setIssuingPerson] = useState('');
  const [issueDate, setIssueDate] = useState('');
  const [submissionDate, setSubmissionDate] = useState('');


  useEffect(() => {
    if (mode === 'edit' && book) {
      setBookId(book.bookId);
      setAuthor(book.author);
      setIssuingPerson(book.issuingPerson);
      setIssueDate(book.issueDate);
      setSubmissionDate(book.submissionDate);
    }
  }, [book, mode]);

  const handleIDChange = (e) => setBookId(e.target.value);
  const handleAuthorChange = (e) => setAuthor(e.target.value);
  const handleIssuingPersonChange = (e) => setIssuingPerson(e.target.value);
  const handleIssueDateChange = (e) => setIssueDate(e.target.value);
  const handleSubmissionDateChange = (e) => setSubmissionDate(e.target.value);


  const handleSubmit = (e) => {
    e.preventDefault();
    const bookData = {
      bookId,
      author,
      issuingPerson,
      issueDate,
      submissionDate,
    };
    onSave(bookData);
    if (mode === 'add') {
      setBookId('');
      setAuthor('');
      setIssuingPerson('');
      setIssueDate('');
      setSubmissionDate('');
    }
  };

  return (
    <div>
      <h2>{mode === 'edit' ? 'Edit Book Details' : 'Add Record'}</h2>
      <form>
        <div>
          <label htmlFor="bookId">Book ID:</label>
          <input
            type="text"
            id="bookId"
            value={bookId}
            onChange={handleIDChange}
          />
        </div>
        <div>
          <label htmlFor="author">Author:</label>
          <input
            type="text"
            id="author"
            value={author}
            onChange={handleAuthorChange}
          />
        </div>
        <div>
          <label htmlFor="issuingPerson">Issuing Person:</label>
          <input
            type="text"
            id="issuingPerson"
            value={issuingPerson}
            onChange={handleIssuingPersonChange}
          />
        </div>
        <div>
          <label htmlFor="issueDate">Issuing Date:</label>
          <input
            type="text"
            id="issueDate"
            value={issueDate}
            onChange={handleIssueDateChange}
          />
        </div>
        <div>
          <label htmlFor="submissionDate">Submission Date:</label>
          <input
            type="text"
            id="submissionDate"
            value={submissionDate}
            onChange={handleSubmissionDateChange}
          />
        </div>
        <div>
          <button type="button" onClick={handleSubmit}>
            {mode === 'edit' ? 'Save' : 'Add'}
          </button>
          <button type="button" onClick={onCancel}>
            Cancel
          </button>
        </div>
      </form>
    </div>
  );
};

export default BookForm;
